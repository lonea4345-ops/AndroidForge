PS5 Style Overlay — Android Studio project

What it does:
- Shows draggable, translucent PS-style labels/buttons and two joystick circles over other apps.
- Works as a visual overlay on Android 7.0+ when the user grants "Display over other apps".

Important limitation:
- This is VISUAL ONLY. It does not send touch events, control BGMI/Free Fire, or emulate a DualSense controller.
- Do not use third-party touch injection/mapping tools with BGMI unless the game explicitly permits them; they may violate game rules and risk account penalties.

Build:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Let Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer it to your Samsung A15 and install it. Android may ask permission to install unknown apps.

Use:
1. Open "PS5 Style Overlay".
2. Tap "Allow display over other apps" and enable permission.
3. Return to the app and tap "Show PS-style buttons".
4. Open BGMI. Drag the translucent labels to positions you like.
5. To hide them, return to the app and tap "Hide overlay".

This project source is provided; no APK has been compiled here.
