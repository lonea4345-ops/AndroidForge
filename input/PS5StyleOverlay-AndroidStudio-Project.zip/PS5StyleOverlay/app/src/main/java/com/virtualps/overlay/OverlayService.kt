package com.virtualps.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addPad("L1", 18, 95, 54)
        addPad("L2", 18, 155, 54)
        addPad("R1", 0, 95, 54, right = true)
        addPad("R2", 0, 155, 54, right = true)
        addPad("△", 0, 225, 62, right = true)
        addPad("□", 0, 295, 62, right = true)
        addPad("○", 0, 365, 62, right = true)
        addPad("✕", 0, 435, 62, right = true)
        addJoystick("L JOY", 22, 250, false)
        addJoystick("R JOY", 0, 250, true)
        addPad("≡", 0, 25, 46, right = true)
    }

    private fun params(size: Int, x: Int, y: Int, right: Boolean): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (right) Gravity.TOP or Gravity.END else Gravity.TOP or Gravity.START)
            this.x = x; this.y = y
        }
    }

    private fun bubble(label: String, size: Int): TextView = TextView(this).apply {
        text = label
        textSize = if (label.length > 2) 11f else 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(105, 20, 25, 38))
            setStroke(2, Color.argb(190, 235, 240, 255))
        }
        alpha = 0.82f
    }

    private fun makeDraggable(view: View, lp: WindowManager.LayoutParams) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                    if (lp.gravity and Gravity.END == Gravity.END) lp.x=(ox-dx).coerceAtLeast(0)
                    else lp.x=(ox+dx).coerceAtLeast(0)
                    lp.y=(oy+dy).coerceAtLeast(0)
                    wm.updateViewLayout(view, lp); true
                }
                else -> true
            }
        }
    }

    private fun addPad(label: String, x: Int, y: Int, size: Int, right: Boolean = false) {
        val v = bubble(label, size)
        val lp = params(size, x, y, right)
        wm.addView(v, lp); makeDraggable(v, lp); views.add(v)
    }

    private fun addJoystick(label: String, x: Int, y: Int, right: Boolean) {
        val size = 92
        val v = FrameLayout(this)
        val outer = TextView(this).apply {
            text = label; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(65, 20, 25, 38))
                setStroke(2, Color.argb(180, 235, 240, 255))
            }
        }
        v.addView(outer, FrameLayout.LayoutParams(size, size))
        val lp = params(size, x, y, right)
        wm.addView(v, lp); makeDraggable(v, lp); views.add(v)
    }

    override fun onDestroy() {
        views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
