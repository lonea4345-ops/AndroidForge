package com.virtualps.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "PS5 Style Overlay"
            textSize = 25f
            setPadding(0, 0, 0, 18)
        }
        val info = TextView(this).apply {
            text = "Transparent on-screen PS-style labels for your phone.\n\nThis is a visual overlay only: it does not press BGMI buttons or map controller inputs."
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Allow display over other apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permission already allowed", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "Show PS-style buttons"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Overlay shown. Return to your game.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "Allow overlay permission first", Toast.LENGTH_LONG).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Hide overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        root.addView(title); root.addView(info); root.addView(permission); root.addView(start); root.addView(stop)
        setContentView(root)
    }
}
