plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.virtualps.overlay"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.virtualps.overlay"
        minSdk = 24
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
